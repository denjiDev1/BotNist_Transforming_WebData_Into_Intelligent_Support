import os
import json

# Directory containing JSON files
json_dir = "C:/Users/Administrator/Downloads/Test_Results/"

# Initialize global metrics
global_metrics = {
    "total_batches": 0,
    "accuracy": 0,
    "recall_at_k": 0,
    "mean_reciprocal_rank": 0,
    "precision_at_k": 0,
    "true_positives": 0,
    "false_positives": 0,
    "false_negatives": 0,
    "f1_score": 0,
    "predictions": [],
    "correct_answers": [],
}

# Process each JSON file
json_files = [f for f in os.listdir(json_dir) if f.endswith(".json")]

for json_file in json_files:
    file_path = os.path.join(json_dir, json_file)
    
    # Load the JSON file
    with open(file_path, "r") as f:
        batch_metrics = json.load(f)
    
    # Update global metrics
    global_metrics["total_batches"] += 1
    global_metrics["accuracy"] += batch_metrics["accuracy"]
    global_metrics["recall_at_k"] += batch_metrics["recall_at_k"]
    global_metrics["mean_reciprocal_rank"] += batch_metrics["mean_reciprocal_rank"]
    global_metrics["precision_at_k"] += batch_metrics["precision_at_k"]
    global_metrics["true_positives"] += batch_metrics["true_positives"]
    global_metrics["false_positives"] += batch_metrics["false_positives"]
    global_metrics["false_negatives"] += batch_metrics["false_negatives"]
    global_metrics["f1_score"] += batch_metrics["f1_score"]
    global_metrics["predictions"].extend(batch_metrics["predictions"])
    global_metrics["correct_answers"].extend(batch_metrics["correct_answers"])

# Average the metrics over all batches
if global_metrics["total_batches"] > 0:
    global_metrics["accuracy"] /= global_metrics["total_batches"]
    global_metrics["recall_at_k"] /= global_metrics["total_batches"]
    global_metrics["mean_reciprocal_rank"] /= global_metrics["total_batches"]
    global_metrics["precision_at_k"] /= global_metrics["total_batches"]
    global_metrics["f1_score"] /= global_metrics["total_batches"]

# Save the global metrics to a JSON file
output_file = "global_metrics.json"
with open(output_file, "w") as f:
    json.dump(global_metrics, f, indent=4)

print(f"Global metrics saved to {output_file}")
